from tkinter import messagebox

class Controlador:
    def __init__(self, modelo, vista):
        self.modelo = modelo
        self.vista = vista
        self.carrito = []

        self.vista.actualizar_catalogo(self.modelo.obtener_productos())
        self.vista.boton_buscar.config(command=self.buscar_producto)
        self.vista.boton_mostrar_todo.config(command=self.mostrar_todo)
        self.vista.boton_agregar.config(command=self.agregar_al_carrito)
        self.vista.boton_mostrar_carrito.config(command=self.mostrar_carrito)
        self.vista.boton_finalizar.config(command=self.finalizar_compra)
        self.vista.boton_limpiar.config(command=self.limpiar_carrito)

    def buscar_producto(self):
        termino = self.vista.entry_busqueda.get()
        productos = self.modelo.buscar_productos(termino)
        self.vista.actualizar_catalogo(productos)

    def mostrar_todo(self):
        productos = self.modelo.obtener_productos()
        self.vista.actualizar_catalogo(productos)

    def agregar_al_carrito(self):
        idx = self.vista.obtener_producto_seleccionado()
        productos = self.modelo.obtener_productos()
        if idx is not None and idx < len(productos):
            self.carrito.append(productos[idx])
            messagebox.showinfo("Carrito", f"Agregado: {productos[idx]['nombre']}")

    def mostrar_carrito(self):
        if not self.carrito:
            messagebox.showinfo("Carrito", "El carrito está vacío.")
            return

        resumen = ""
        total = 0
        for producto in self.carrito:
            resumen += f"{producto['nombre']} - ${producto['precio']}\n"
            total += producto['precio']
        resumen += f"\nTotal: ${total}"
        messagebox.showinfo("Carrito", resumen)

    def finalizar_compra(self):
        if not self.carrito:
            messagebox.showinfo("Compra", "El carrito está vacío.")
            return
        total = sum(p['precio'] for p in self.carrito)
        self.carrito = []
        messagebox.showinfo("Compra realizada", f"Gracias por tu compra.\nTotal pagado: ${total}")

    def limpiar_carrito(self):
        self.carrito = []
        messagebox.showinfo("Carrito", "El carrito ha sido vaciado.")
