import json

class Modelo:
    def __init__(self, archivo_productos="productos.json"):
        self.archivo_productos = archivo_productos
        self.productos = self.cargar_productos()

    def cargar_productos(self):
        with open(self.archivo_productos, "r", encoding="utf-8") as f:
            return json.load(f)

    def obtener_productos(self):
        return self.productos

    def buscar_productos(self, termino):
        termino = termino.lower()
        return [p for p in self.productos if termino in p["nombre"].lower()]
