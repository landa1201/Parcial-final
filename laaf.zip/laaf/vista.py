import tkinter as tk
from tkinter import messagebox

class Vista:
    def __init__(self, root):
        self.root = root
        self.root.title("Tienda de Moda")
        self.catalogo_frame = tk.Frame(self.root)
        self.catalogo_frame.pack()

        self.entry_busqueda = tk.Entry(self.root)
        self.entry_busqueda.pack(pady=5)

        self.boton_buscar = tk.Button(self.root, text="Buscar")
        self.boton_buscar.pack(pady=2)

        self.boton_mostrar_todo = tk.Button(self.root, text="Mostrar todo")
        self.boton_mostrar_todo.pack(pady=2)

        self.lista_catalogo = tk.Listbox(self.catalogo_frame, width=50)
        self.lista_catalogo.pack(side=tk.LEFT, padx=10)

        self.boton_agregar = tk.Button(self.root, text="Agregar al carrito")
        self.boton_agregar.pack(pady=2)

        self.boton_mostrar_carrito = tk.Button(self.root, text="Mostrar carrito")
        self.boton_mostrar_carrito.pack(pady=2)

        self.boton_finalizar = tk.Button(self.root, text="Finalizar compra")
        self.boton_finalizar.pack(pady=2)

        self.boton_limpiar = tk.Button(self.root, text="Limpiar carrito")
        self.boton_limpiar.pack(pady=2)

    def actualizar_catalogo(self, productos):
        self.lista_catalogo.delete(0, tk.END)
        for producto in productos:
            self.lista_catalogo.insert(tk.END, f"{producto['nombre']} - ${producto['precio']}")

    def obtener_producto_seleccionado(self):
        seleccion = self.lista_catalogo.curselection()
        if seleccion:
            return seleccion[0]
        return None
